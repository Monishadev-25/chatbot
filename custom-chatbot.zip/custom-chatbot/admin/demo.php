<?php
// admin/chatbot-admin.php

add_action('admin_menu', 'chatbot_register_menu');

function chatbot_register_menu() {
    add_menu_page(
        'Chatbot Manager',
        'Chatbot Manager',
        'manage_options',
        'chatbot-manager',
        'chatbot_admin_page',
        'dashicons-format-chat',
        60
    );
}

function chatbot_admin_page() {
    global $wpdb;

    $questions_table = $wpdb->prefix . 'chatbot_questions';
    $options_table = $wpdb->prefix . 'chatbot_options';
    $playlists_table = $wpdb->prefix . 'chatbot_playlists';

    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['question_id'])) {
        $qid = intval($_GET['question_id']);

        $option_ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $options_table WHERE question_id = %d", $qid));
        if ($option_ids) {
            foreach ($option_ids as $oid) {
                $wpdb->delete($playlists_table, ['option_id' => $oid]);
            }
        }
        $wpdb->delete($options_table, ['question_id' => $qid]);
        $wpdb->delete($questions_table, ['id' => $qid]);

        echo '<div class="updated notice"><p>Question deleted successfully.</p></div>';
    }

    // Handle Add Question
    if (isset($_POST['submit_question'])) {
        $question = sanitize_textarea_field($_POST['question']);
        $initial = $wpdb->get_var("SELECT COUNT(*) FROM $questions_table WHERE question_order = 1");
        $question_order = $initial ? 0 : 1;
        $wpdb->insert($questions_table, [
            'question' => $question,
            'question_order' => $question_order,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ]);
        echo '<div class="updated notice"><p>Question added successfully.</p></div>';
    }

    // Handle Option Linking
    if (isset($_POST['submit_link_option'])) {
        $question_id = intval($_POST['link_question_id']);
        $option_type = sanitize_text_field($_POST['option_type']);

        if ($option_type === 'single') {
            $redirect_id = intval($_POST['redirect_question_id']);
            $wpdb->insert($options_table, [
                'question_id' => $question_id,
                'option_type' => $option_type,
                'option_value' => '',
                'redirect_question_id' => $redirect_id
            ]);
        } elseif ($option_type === 'radio' || $option_type === 'checkbox') {
            $option_values = $_POST['option_value'];
            $redirect_ids = $_POST['redirect_question_id'];
            $playlist_ids = $_POST['playlist_ids'];

            foreach ($option_values as $i => $val) {
                $opt_val = sanitize_text_field($val);
                $redirect_id = intval($redirect_ids[$i]);
                $selected_playlists = isset($playlist_ids[$i]) ? $playlist_ids[$i] : [];

                $wpdb->insert($options_table, [
                    'question_id' => $question_id,
                    'option_type' => $option_type,
                    'option_value' => $opt_val,
                    'redirect_question_id' => $redirect_id
                ]);

                $option_id = $wpdb->insert_id;

                foreach ($selected_playlists as $media_id) {
                    $link = wp_get_attachment_url($media_id);
                    if ($link) {
                        $wpdb->insert($playlists_table, [
                            'option_id' => $option_id,
                            'playlist_link' => esc_url_raw($link)
                        ]);
                    }
                }
            }
        }

        echo '<div class="updated notice"><p>Options and playlists saved successfully.</p></div>';
    }

    // Setup Pagination
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 10;
    $offset = ($paged - 1) * $per_page;

    $total_questions = $wpdb->get_var("SELECT COUNT(*) FROM $questions_table");
    $total_pages = ceil($total_questions / $per_page);

    $all_questions = $wpdb->get_results("SELECT * FROM $questions_table ORDER BY question_order DESC, id ASC");
    $questions = $wpdb->get_results($wpdb->prepare("SELECT * FROM $questions_table ORDER BY question_order DESC, id ASC LIMIT %d OFFSET %d", $per_page, $offset));

    $media_items = get_posts([
        'post_type' => 'attachment',
        'post_mime_type' => 'video',
        'numberposts' => -1
    ]);

    echo '<div class="wrap">';
    echo '<h1>Chatbot Question Manager</h1>';

    echo '<button id="add-question-btn" class="button button-primary">Add Question</button>';
    echo '<div id="add-question-modal" style="display:none; margin-top: 15px;">';
    echo '<form method="post">';
    echo '<textarea name="question" required style="width:100%; height:80px;"></textarea><br><br>';
    echo '<input type="submit" name="submit_question" class="button button-primary" value="Save Question">';
    echo '</form></div>';

    echo '<h2 style="margin-top: 40px;">Link Options to Question</h2>';
    echo '<form method="post" id="link-question-form">';
    echo '<label>Select Question:</label><br>';
    echo '<select name="link_question_id" required>';
    foreach ($all_questions as $q) {
        echo "<option value='{$q->id}'>{$q->question}</option>";
    }
    echo '</select><br><br>';
    echo '<label>Option Type:</label><br>';
    echo '<select name="option_type" id="option_type" required>';
    echo '<option value="">Select</option>';
    echo '<option value="single">Single</option>';
    echo '<option value="radio">Radio</option>';
    echo '<option value="checkbox">Checkbox</option>';
    echo '</select><br><br>';
    echo '<div id="dynamic_option_fields"></div>';
    echo '<input type="submit" name="submit_link_option" class="button button-primary" value="Link Options">';
    echo '</form>';

    echo '<table class="widefat fixed striped" style="margin-top: 40px;">';
    echo '<thead><tr><th>S.No</th><th>Question</th><th>Option Type</th><th colspan="3">Options / Redirect / Playlists</th><th>Actions</th></tr></thead><tbody>';

    $serial = ($paged - 1) * $per_page + 1;
    foreach ($questions as $question) {
        $options = $wpdb->get_results($wpdb->prepare("SELECT * FROM $options_table WHERE question_id = %d", $question->id));
        $option_type = $options ? implode(', ', array_unique(array_column($options, 'option_type'))) : '-';
        $options_html = '';

        foreach ($options as $opt) {
            $redirect_q = $opt->redirect_question_id ? $wpdb->get_var($wpdb->prepare("SELECT question FROM $questions_table WHERE id = %d", $opt->redirect_question_id)) : '-';
            $playlists = $wpdb->get_col($wpdb->prepare("SELECT playlist_link FROM $playlists_table WHERE option_id = %d", $opt->id));
            $playlist_links = $playlists ? implode(', ', $playlists) : '-';

            $options_html .= "<div><strong>{$opt->option_value}</strong><br>Redirect: {$redirect_q}<br>Playlists: {$playlist_links}</div>";
        }

        echo "<tr><td>{$serial}</td><td>{$question->question}</td><td>{$option_type}</td><td colspan='3'>{$options_html}</td><td>
        <a href='" . admin_url("admin.php?page=chatbot-manager&action=delete&question_id={$question->id}") . "' class='button' onclick=\"return confirm('Are you sure?');\">Delete</a></td></tr>";

        $serial++;
    }

    echo '</tbody></table>';

    echo '<div class="tablenav"><div class="tablenav-pages">';
    $base_url = admin_url('admin.php?page=chatbot-manager');
    for ($i = 1; $i <= $total_pages; $i++) {
        echo $i == $paged ? "<span class='button'>$i</span> " : "<a class='button' href='{$base_url}&paged=$i'>$i</a> ";
    }
    echo '</div></div>';
    echo '</div>';

    ?>
    <script>
    document.getElementById("add-question-btn").addEventListener("click", function () {
        const modal = document.getElementById("add-question-modal");
        modal.style.display = modal.style.display === "none" ? "block" : "none";
    });

    document.getElementById("option_type").addEventListener("change", function () {
        const type = this.value;
        const container = document.getElementById("dynamic_option_fields");
        const questionsHtml = document.querySelector("select[name='link_question_id']").innerHTML;
        const mediaOptions = `<?php foreach ($media_items as $m) echo "<option value='{$m->ID}'>{$m->post_title}</option>"; ?>`;

        if (type === 'single') {
            container.innerHTML = `<label>Redirect To:</label><br><select name='redirect_question_id'>${questionsHtml}</select>`;
        } else if (type === 'radio' || type === 'checkbox') {
            container.innerHTML = `<div id='option_repeaters'><div class='option-block'>
                <input name='option_value[]' placeholder='Option Label' required>
                <select name='redirect_question_id[]'>${questionsHtml}</select>
                <select name='playlist_ids[0][]' multiple>${mediaOptions}</select>
                <button type='button' class='remove-option'>-</button>
            </div></div><button type='button' id='add-option'>Add Option +</button>`;

            setTimeout(() => {
                let optionIndex = 1;
                document.getElementById("add-option").addEventListener("click", () => {
                    const block = document.querySelector(".option-block");
                    const clone = block.cloneNode(true);
                    clone.querySelectorAll("input").forEach(input => input.value = "");
                    clone.querySelector("select[name^='playlist_ids']").name = `playlist_ids[${optionIndex}][]`;
                    optionIndex++;
                    document.getElementById("option_repeaters").appendChild(clone);
                });
                document.querySelectorAll(".remove-option").forEach(btn => {
                    btn.addEventListener("click", e => e.target.parentNode.remove());
                });
            }, 100);
        } else {
            container.innerHTML = '';
        }
    });
    </script>
    <?php
}
