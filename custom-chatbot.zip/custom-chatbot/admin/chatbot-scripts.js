document.addEventListener('DOMContentLoaded', function () {
  const optionTypeDropdown = document.getElementById('option_type');
  const dynamicFields = document.getElementById('dynamic_fields');

  optionTypeDropdown?.addEventListener('change', function () {
    const type = this.value;
    fetch(`admin-ajax.php?action=load_option_fields&type=${type}`)
      .then(res => res.text())
      .then(html => {
        dynamicFields.innerHTML = html;
      });
  });
});
