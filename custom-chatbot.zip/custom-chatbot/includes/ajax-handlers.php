<?php
// AJAX: Get first question
add_action('wp_ajax_chatbot_get_first', 'chatbot_get_first_question');
add_action('wp_ajax_nopriv_chatbot_get_first', 'chatbot_get_first_question');

function chatbot_get_first_question() {
    global $wpdb;
    $table = $wpdb->prefix . 'chatbot_questions';
    $question = $wpdb->get_row("SELECT * FROM $table WHERE question_order = 1 LIMIT 1");
    wp_send_json_success($question);
}

// AJAX: Get specific question + options
add_action('wp_ajax_chatbot_get_question', 'chatbot_get_question_data');
add_action('wp_ajax_nopriv_chatbot_get_question', 'chatbot_get_question_data');

function chatbot_get_question_data() {
    global $wpdb;
    $qid = intval($_GET['question_id']);
    $questions = $wpdb->prefix . 'chatbot_questions';
    $options = $wpdb->prefix . 'chatbot_options';
    $playlists = $wpdb->prefix . 'chatbot_playlists';

    $q = $wpdb->get_row($wpdb->prepare("SELECT * FROM $questions WHERE id = %d", $qid));

    // Get all options with attached playlists
    $opts_raw = $wpdb->get_results($wpdb->prepare("SELECT * FROM $options WHERE question_id = %d", $qid));

    $opts = [];
    foreach ($opts_raw as $opt) {
        $links = $wpdb->get_col($wpdb->prepare("SELECT playlist_link FROM $playlists WHERE option_id = %d", $opt->id));
        $opt->playlist_links = $links;
        $opts[] = $opt;
    }

    wp_send_json_success([
        'question' => $q,
        'options' => $opts
    ]);
}

// Handle feedback submission
add_action('wp_ajax_chatbot_submit_feedback', 'chatbot_submit_feedback');
add_action('wp_ajax_nopriv_chatbot_submit_feedback', 'chatbot_submit_feedback'); // If guests allowed

function chatbot_submit_feedback() {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'You must be logged in to submit feedback.']);
    }

    if (!isset($_POST['rating'], $_POST['comment'])) {
        wp_send_json_error(['message' => 'Missing data.']);
    }

    $user_id = get_current_user_id(); // 0 if guest
    $rating = intval($_POST['rating']);
    $comment = sanitize_textarea_field($_POST['comment']);

    global $wpdb;
    $table = $wpdb->prefix . 'chatbot_feedback';

    $inserted = $wpdb->insert($table, [
        'user_id' => $user_id,
        'rating' => $rating,
        'comment' => $comment,
        'submitted_at' => current_time('mysql')
    ]);

    if ($inserted) {
        wp_send_json_success(['message' => 'Feedback saved.']);
    } else {
        wp_send_json_error(['message' => 'DB insert failed.']);
    }
}

add_action('wp_ajax_chatbot_save_playlist', 'chatbot_save_playlist');
add_action('wp_ajax_nopriv_chatbot_save_playlist', 'chatbot_save_playlist');

function chatbot_save_playlist() {
    global $wpdb;

    $user_id = get_current_user_id(); // 0 if not logged in
    $table = $wpdb->prefix . 'chatbot_user_playlists';

    $links = json_decode(stripslashes($_POST['playlist'] ?? '[]'), true);

    if (!is_array($links) || empty($links)) {
        wp_send_json(['success' => false, 'message' => 'No valid playlist received.']);
    }

    foreach ($links as $link) {
        // Convert to relative path (e.g., /wp-content/uploads/...)
        $relative_link = wp_make_link_relative($link);

        // Extract only the part starting from "uploads/"
        if (preg_match('#/uploads/(.*)$#', $relative_link, $matches)) {
            $clean_link = 'uploads/' . $matches[1];

            $wpdb->insert($table, [
                'user_id' => $user_id,
                'playlist_links' => $clean_link,
                'created_at' => current_time('mysql')
            ]);
        }
    }

    wp_send_json(['success' => true]);
}




