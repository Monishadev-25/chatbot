<?php
// includes/db-functions.php

function chatbot_create_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    $questions = $wpdb->prefix . 'chatbot_questions';
    $options = $wpdb->prefix . 'chatbot_options';
    $playlists = $wpdb->prefix . 'chatbot_playlists';

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // --- Create Questions Table ---
    $sql1 = "CREATE TABLE $questions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        question TEXT NOT NULL,
        question_order TINYINT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // --- Create Options Table ---
    $sql2 = "CREATE TABLE $options (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        question_id BIGINT UNSIGNED NOT NULL,
        option_type ENUM('single','radio','checkbox') NOT NULL,
        option_value VARCHAR(255),
        redirect_question_id BIGINT UNSIGNED DEFAULT NULL,
        PRIMARY KEY (id),
        KEY question_id (question_id),
        KEY redirect_question_id (redirect_question_id)
    ) $charset_collate;";

    // --- Create Playlists Table ---
    $sql3 = "CREATE TABLE $playlists (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        option_id BIGINT UNSIGNED NOT NULL,
        playlist_link TEXT NOT NULL,
        PRIMARY KEY (id),
        KEY option_id (option_id)
    ) $charset_collate;";

    $feedback = $wpdb->prefix . 'chatbot_feedback';
    $sql4 = "CREATE TABLE $feedback (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        comment TEXT NOT NULL,
        rating INT NOT NULL,
        submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    $user_playlists = $wpdb->prefix . 'chatbot_user_playlists';
    $sql5 = "CREATE TABLE $user_playlists (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        playlist_links TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";

    // Create all tables at once
    dbDelta($sql1);
    dbDelta($sql2);
    dbDelta($sql3);
    dbDelta($sql4);
    dbDelta($sql5);
    
    // Add foreign keys manually using direct SQL (dbDelta does not support FK constraints well)
    $wpdb->query("ALTER TABLE $options ADD CONSTRAINT fk_question FOREIGN KEY (question_id) REFERENCES $questions(id) ON DELETE CASCADE");
    $wpdb->query("ALTER TABLE $options ADD CONSTRAINT fk_redirect FOREIGN KEY (redirect_question_id) REFERENCES $questions(id) ON DELETE SET NULL");
    $wpdb->query("ALTER TABLE $playlists ADD CONSTRAINT fk_option FOREIGN KEY (option_id) REFERENCES $options(id) ON DELETE CASCADE");

    // Insert default welcome question if not already present
    $existing = $wpdb->get_var("SELECT COUNT(*) FROM $questions");
    if ($existing == 0) {
        $wpdb->insert(
            $questions,
            [
                'question' => 'Welcome!',
                'question_order' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ]
        );
    }
}

// Run this on plugin activation
register_activation_hook(__FILE__, 'chatbot_create_tables');