<?php
add_shortcode('chatbot_ui', 'chatbot_ui_shortcode');

function chatbot_ui_shortcode() {
    ob_start(); ?>
    <!-- Floating Chat Button -->
    <div id="floating-chat-button" class="floating-chat-button">
        💬
    </div>

    <!-- Chatbot Window -->
    <div id="chatbox" class="chatbox-wrapper" style="display:none;">
        <div class="chatbox-header">
            <span>Chatbot</span>
        </div>
        <div class="chatbox-content" id="chatbox-content"></div>
    </div>

    <style>
        .floating-chat-button {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background-color: #3f51b5;
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 60px;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
            z-index: 9999;
        }
        .chatbox-wrapper {
            position: fixed;
            bottom: 100px;
            right: 30px;
            width: 360px;
            height: 500px;
            font-family: Arial, sans-serif;
            padding: 15px;
            border-radius: 12px;
            background: #f2f2f2;
            overflow-y: auto;
            border: 1px solid #ccc;
            z-index: 9999;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .chatbox-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: bold;
            background: #3f51b5;
            color: #fff;
            padding: 10px;
            border-radius: 10px 10px 0 0;
            margin: -15px -15px 10px -15px;
        }
        #close-chat-btn {
            background: transparent;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }
        .chat-message {
            padding: 10px 15px;
            margin: 8px 0;
            border-radius: 15px;
            max-width: 80%;
            clear: both;
        }
        .bot {
            font-size:18px;
            background: #fff;
            float: left;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .user {
            font-size:18px;
            background: #3f51b5;
            color: white;
            float: right;
        }
        .typing {
            font-style: italic;
            color: #888;
        }
        .option-form {
            margin-top: 10px;
            clear: both;
        }
        .option-form label {
            display: block;
            margin: 6px 0;
             font-size:18px;
        }
        .option-form input[type="radio"],
        .option-form input[type="checkbox"] {
            margin-right: 8px;
        }
        .playlist-box {
            background: #3f51b5;
            color: #fff;
            padding: 10px;
            border-radius: 10px;
            margin-top: 10px;
            display: inline-block;
        }
        .playlist-box a {
            color: #fff;
            display: block;
            margin-top: 5px;
        }
    </style>

    <script>
        function scrollToBottom() {
            requestAnimationFrame(() => {
                chatbox.scrollTop = chatbox.scrollHeight;
            });
        }
    document.addEventListener("DOMContentLoaded", () => {
        const chatbox = document.getElementById("chatbox-content");
        const chatWrapper = document.getElementById("chatbox");
        const startBtn = document.getElementById("floating-chat-button");
        const closeBtn = document.getElementById("close-chat-btn");

        startBtn.addEventListener("click", () => {
            const isVisible = chatWrapper.style.display === "block";
            if (isVisible) {
                // Close chat
                chatWrapper.style.display = "none";
                chatbox.innerHTML = '';
                startBtn.innerText = "💬";
            } else {
                // Open chat fresh
                chatbox.innerHTML = ''; // Clear OLD content before anything
                chatWrapper.style.display = "block";
                startBtn.innerText = "❌";
                startChat(); // Start from first question
            }
        });

        function showTyping(callback) {
            const typing = document.createElement("div");
            typing.className = "chat-message bot typing";
            typing.innerText = "Typing...";
            chatbox.appendChild(typing);
            scrollToBottom();
            //chatbox.scrollTop = chatbox.scrollHeight;
            setTimeout(() => {
                typing.remove();
                callback();
            }, 800);
        }

        function showBotMessage(text) {
            const msg = document.createElement("div");
            msg.className = "chat-message bot";
            msg.innerText = text;
            chatbox.appendChild(msg);
            scrollToBottom();
            //chatbox.scrollTop = chatbox.scrollHeight;
        }

        function showUserMessage(text) {
            if (!text || text.trim() === "") return;
            const msg = document.createElement("div");
            msg.className = "chat-message user";
            msg.innerText = text;
            chatbox.appendChild(msg);
            scrollToBottom();
            //chatbox.scrollTop = chatbox.scrollHeight;
        }

        function showPlaylist(links) {
            const box = document.createElement("div");
            box.className = "chat-message user playlist-box";
            box.innerHTML = '<strong>Your playlist:</strong><br>';
            
            links.forEach(link => {
                const a = document.createElement("a");
                a.href = link;
                a.target = '_blank';
                a.innerText = link;
                a.style.display = "block";
                box.appendChild(a);
            });

            chatbox.appendChild(box);
            scrollToBottom();

            // Save to user playlist table via AJAX
            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=chatbot_save_playlist', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `playlist=${encodeURIComponent(JSON.stringify(links))}`
            })
            .then(res => res.json())
            .then(data => {
                if (!data.success) {
                    console.error('Playlist save failed:', data);
                }
            });
        }



       function showFeedbackForm() {
            const form = document.createElement("form");
            form.className = "option-form";
            form.style.marginTop = "10px";

            form.innerHTML = `
                <style>
                    .star-rating {
                        direction: rtl;
                        font-size: 1.8em;
                        display: inline-flex;
                        gap: 5px;
                    }
                    .star-rating input {
                        display: none;
                    }
                    .star-rating label {
                        cursor: pointer;
                        color: #ccc;
                        transition: color 0.2s;
                    }
                    .star-rating input:checked ~ label,
                    .star-rating label:hover,
                    .star-rating label:hover ~ label {
                        color: gold;
                    }
                    .feedback-comment {
                        width: 100%;
                        padding: 8px;
                        margin-top: 10px;
                        font-size: 14px;
                        box-sizing: border-box;
                    }
                    .feedback-submit {
                        margin-top: 10px;
                        padding: 10px;
                        background: #0073aa;
                        color: #fff;
                        border: none;
                        cursor: pointer;
                        font-size: 16px;
                    }
                    .feedback-submit:hover {
                        background: #005c8e;
                    }
                </style>

                <label>Rating:</label>
                <div class="star-rating">
                    <input type="radio" name="rating" id="star5" value="5" required><label for="star5">★</label>
                    <input type="radio" name="rating" id="star4" value="4"><label for="star4">★</label>
                    <input type="radio" name="rating" id="star3" value="3"><label for="star3">★</label>
                    <input type="radio" name="rating" id="star2" value="2"><label for="star2">★</label>
                    <input type="radio" name="rating" id="star1" value="1"><label for="star1">★</label>
                </div>

                <label>Comment:</label>
                <textarea name="comment" class="feedback-comment" required rows="3" placeholder="Write your feedback..."></textarea>

                <button type="submit" class="feedback-submit">Submit Feedback</button>
            `;

            form.onsubmit = e => {
                e.preventDefault();
                const ratingInput = form.querySelector('input[name="rating"]:checked');
                const comment = form.comment.value.trim();

                if (!ratingInput) {
                    showBotMessage("Please select a rating.");
                    return;
                }

                const rating = ratingInput.value;

                fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=chatbot_submit_feedback', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: `rating=${encodeURIComponent(rating)}&comment=${encodeURIComponent(comment)}`
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        showUserMessage(`⭐ ${rating} - ${comment}`);
                        showBotMessage("Thank you for your feedback!");
                        form.remove();
                    } else {
                        showBotMessage("Failed to submit feedback. Try again.");
                        console.error(data);
                    }
                });
            };

            chatbox.appendChild(form);
            scrollToBottom();
        }

        function fetchQuestion(questionId) {
        
            fetch(`<?php echo admin_url('admin-ajax.php'); ?>?action=chatbot_get_question&question_id=${questionId}`)
                .then(res => res.json())
                .then(data => {
                    if (!data.success) return;
                    const { question, options } = data.data;

                    showTyping(() => {
                        if (question.question.trim().toLowerCase() === "feedback") {
                            showBotMessage(question.question); // Optional
                            showFeedbackForm(); // 👈 Add this custom function
                            return; // Stop normal flow
                        }
                        showBotMessage(question.question);

                        if (!options.length) {
                            return;
                        }

                        const type = options[0].option_type;

                        if (type === 'single' && options.length === 1) {
                            // Skip showing user message or playlist if only one option exists
                            const val = options[0];
                            if (parseInt(val.redirect_question_id) !== 1 && val.redirect_question_id) {
                                fetchQuestion(val.redirect_question_id);
                            }
                            return;
                        }

                        const form = document.createElement("form");
                        form.className = "option-form";

                        options.forEach(opt => {
                            const label = document.createElement("label");
                            const input = document.createElement("input");

                            input.name = (type === 'checkbox') ? `opt_${opt.question_id}[]` : 'opt';
                            input.type = (type === 'checkbox' ? 'checkbox' : 'radio');
                            input.value = JSON.stringify({
                                label: opt.option_value,
                                redirect: opt.redirect_question_id,
                                playlist: opt.playlist_links || []
                            });

                            label.appendChild(input);
                            label.appendChild(document.createTextNode(opt.option_value));
                            form.appendChild(label);

                            if (type !== 'checkbox') {
                                input.addEventListener('change', () => {
                                    const val = JSON.parse(input.value);
                                    showUserMessage(val.label);
                                    if (val.playlist.length) showPlaylist(val.playlist);
                                    form.remove();
                                    if (parseInt(val.redirect) === 1 || !val.redirect) return;
                                    fetchQuestion(val.redirect);
                                });
                            }
                        });

                        if (type === 'checkbox') {
                            const nextBtn = document.createElement("button");
                            nextBtn.type = 'submit';
                            nextBtn.innerText = 'Next';
                            form.appendChild(nextBtn);

                            form.onsubmit = (e) => {
                                e.preventDefault();
                                const selected = form.querySelectorAll('input:checked');
                                if (!selected.length) return;

                                const labels = [], redirectSet = new Set(), allPlaylists = [];
                                selected.forEach(input => {
                                    const val = JSON.parse(input.value);
                                    labels.push(val.label);
                                    redirectSet.add(val.redirect);
                                    allPlaylists.push(...val.playlist);
                                });

                                showUserMessage(labels.join(', '));
                                if (allPlaylists.length > 0) showPlaylist(allPlaylists);

                                const nextId = [...redirectSet][0];
                                if (parseInt(nextId) === 1 || !nextId) return;
                                form.remove();
                                fetchQuestion(nextId);
                            };
                        }

                        chatbox.appendChild(form);
                       // chatbox.scrollTop = chatbox.scrollHeight;
                        scrollToBottom();
                    });
                });
        }

        function startChat() {
            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=chatbot_get_first')
                .then(res => res.json())
                .then(data => {
                    if (data.success) fetchQuestion(data.data.id);
                });
        }
    });
    </script>
    <?php
    return ob_get_clean();
}
