<?php
/**
 * Plugin Name: Custom Chatbot Plugin
 * Description: A chatbot plugin with question flow, redirection, and playlist mapping.
 * Version: 1.0
 * Author: Your Name
 */

// Define constants
define('CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once CHATBOT_PLUGIN_DIR . 'includes/db-functions.php';
require_once CHATBOT_PLUGIN_DIR . 'admin/chatbot-admin.php';
require_once CHATBOT_PLUGIN_DIR . 'includes/chatbot-frontend.php';
require_once CHATBOT_PLUGIN_DIR . 'includes/ajax-handlers.php';

// Run activation hook to create DB tables
register_activation_hook(__FILE__, 'chatbot_create_tables');

// Enqueue admin scripts and styles
function chatbot_enqueue_admin_assets($hook) {
    if (strpos($hook, 'chatbot-manager') === false) return;

    wp_enqueue_style('chatbot-admin-style', CHATBOT_PLUGIN_URL . 'admin/chatbot-styles.css');
    wp_enqueue_script('chatbot-admin-script', CHATBOT_PLUGIN_URL . 'admin/chatbot-scripts.js', ['jquery'], false, true);
}
add_action('admin_enqueue_scripts', 'chatbot_enqueue_admin_assets');
 